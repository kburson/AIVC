import { fetchIssueProjectMembership } from '../../gh/lib/project-membership.mjs';
// `/task plan` — dedicated Ready for Planning→Plan promoter (#299 Item 2).
//
// Before #299 this verb was a deprecated alias for `/task discover`. That
// shape collided with the kanban-state rename Analyze→Plan: `/task plan #N`
// would start a discovery bucket instead of entering the Sprint-Planning
// state. This verb mirrors the `/task refine`, `/task test`, `/task review`
// pattern — a thin wrapper around `verbPromote` for its target state — with
// a live-state pre-check that refuses anything but an R4P→Plan transition.
//
// Discovery (backlog-item generation / pre-issue ideation) lives in
// `verbs/discover.mjs` and is the only home for that workflow.
//
// CLI:
//   /task plan <issue#>
//
// Exit codes:
//   0  success
//   1  wrong-state / promote failure
//   2  usage error

import { verbPromote } from './promote.mjs';
import { normalizeStateId } from '../lib/lifecycle-policy/index.mjs';
import { assertBoundToIssue } from '../lib/bind-context.mjs';

function parseArgs(rest = []) {
  for (const a of rest) {
    const m = String(a).match(/^#?(\d+)$/);
    if (m) return { issueNumber: Number(m[1]) };
  }
  return { issueNumber: null };
}

async function defaultGetLiveState({ issueNumber, cfg }) {
  const { item } = await fetchIssueProjectMembership({
    repo: cfg.repo,
    projectId: cfg.projectId,
    issueNumber,
  });
  return normalizeStateId(item?.fieldValueByName?.name);
}

export async function runPlan({ issueNumber, cfg, deps = {} } = {}) {
  if (!cfg) throw new Error('plan: cfg is required');
  if (!Number.isInteger(issueNumber) || issueNumber <= 0) {
    throw new Error('plan: issue# must be a positive integer');
  }
  const assertBound = deps.assertBound ?? assertBoundToIssue;
  assertBound(issueNumber);
  const getLiveState = deps.getLiveState || defaultGetLiveState;
  const promote = deps.verbPromote || verbPromote;

  const current = await getLiveState({ issueNumber, cfg });
  if (current !== 'ready-for-plan') {
    return {
      status: 'wrong-state',
      issueNumber,
      current,
      message:
        `plan: refuses to run on #${issueNumber} — current state is \`${current ?? 'unknown'}\`, expected \`ready-for-plan\`. ` +
        `\`/task plan\` only enters Sprint-Planning from Ready for Planning. ` +
        `For backlog item generation use \`/task discover\`; for other transitions use \`/task promote\`.`,
    };
  }

  await promote([String(issueNumber)], cfg, { ...deps, cursorCommand: 'plan' });
  return { status: 'promoted', issueNumber, from: 'ready-for-plan', to: 'plan' };
}

export async function verbPlan(ctx) {
  const { cfg, rest, deps } = ctx;
  const { issueNumber } = parseArgs(rest);
  if (!issueNumber) {
    process.stderr.write('Usage: /task plan <issue#>\n');
    process.stderr.write(
      '  Promotes <issue#> from Ready for Planning to Plan (Sprint-Planning entry). For backlog item generation use `/task discover`.\n'
    );
    process.exit(2);
  }
  let result;
  try {
    result = await runPlan({ issueNumber, cfg, deps });
  } catch (err) {
    process.stderr.write(`plan: ${err.message}\n`);
    process.exit(1);
  }
  if (result.status === 'wrong-state') {
    process.stderr.write(`⛔ ${result.message}\n`);
    process.exit(1);
  }
}
